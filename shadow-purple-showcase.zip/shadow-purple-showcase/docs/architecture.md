# Arquitectura de Shadow Purple

## Visión general

Describe en 3 o 4 líneas cómo funciona el sitio: qué ve el usuario, qué pasa por detrás y dónde se despliega.

```
Usuario → Navegador → Frontend (páginas/componentes)
                         ↓
                    API / Backend (si aplica)
                         ↓
                  Datos (JSON, base de datos, etc.)
```

## Módulos principales

- **Inicio:** TODO
- **Proyectos / Portafolio:** TODO
- **Sobre mí:** TODO
- **Contacto:** TODO

## Flujo de despliegue

1. Cambios en el repo privado
2. Build automático
3. Publicación en el hosting

## Diseño visual

- Paleta principal: morado oscuro (shadow purple) con acentos TODO
- Tipografía: TODO
- Enfoque responsive: TODO
