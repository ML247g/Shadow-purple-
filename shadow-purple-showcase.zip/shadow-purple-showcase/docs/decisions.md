# Decisiones técnicas

Formato: **Decisión → Alternativas → Razón**

## 1. TODO: elección del stack
- **Elegí:** TODO
- **Alternativas:** TODO
- **Razón:** TODO

## 2. TODO: elección del hosting
- **Elegí:** TODO
- **Alternativas:** TODO
- **Razón:** TODO

## 3. Repositorio de código privado + vitrina pública
- **Elegí:** separar el código (privado) de la documentación (pública)
- **Razón:** poder mostrar mi trabajo a reclutadores sin exponer archivos internos

## Qué aprendí
- TODO
- TODO
