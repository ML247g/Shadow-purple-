# Stack tecnológico

## Frontend
- Tecnología: TODO
- Por qué: TODO

## Backend / Datos
- Tecnología: TODO
- Por qué: TODO

## Herramientas de desarrollo
- Editor: TODO
- Control de versiones: Git / GitHub
- Despliegue: TODO

## Seguridad básica
- Variables sensibles fuera del repo (`.env`)
- Repositorio de código privado
