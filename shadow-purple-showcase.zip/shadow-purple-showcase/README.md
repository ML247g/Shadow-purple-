# 🟣 Shadow Purple

Mi sitio web personal. Este repositorio es una **vitrina pública**: muestra cómo está construido el proyecto (arquitectura, stack y decisiones técnicas) sin exponer el código fuente, que es privado.

🔗 **Demo:** https://TU-DOMINIO.com
👤 **Autor:** Yulian Julio Mendoza ([@TU-USUARIO](https://github.com/TU-USUARIO))

---

## Vista previa

![Inicio](assets/screenshots/home.png)

> Agrega aquí 2 o 3 capturas en `assets/screenshots/`.

## Stack

| Capa | Tecnología |
|------|------------|
| Frontend | TODO (HTML/CSS/JS, React, Astro…) |
| Backend | TODO (Node.js, TypeScript…) |
| Estilos | TODO (CSS puro, Tailwind…) tema morado "shadow purple" |
| Hosting | TODO (Vercel, Netlify, GitHub Pages…) |
| Control de versiones | Git + GitHub (repo de código privado) |

Más detalle en [`docs/tech-stack.md`](docs/tech-stack.md).

## Arquitectura

Resumen en [`docs/architecture.md`](docs/architecture.md) y estructura de carpetas en [`structure/project-tree.txt`](structure/project-tree.txt).

## Decisiones técnicas

Por qué elegí cada herramienta: [`docs/decisions.md`](docs/decisions.md).

## ¿Por qué el código es privado?

El repositorio principal contiene configuración y recursos que prefiero no exponer. Si eres reclutador y quieres revisar el código, escríbeme y te doy acceso.

## Contacto

- LinkedIn: TODO
- Correo: TODO
- GitHub: https://github.com/TU-USUARIO
